package uikt.uiktpteamretrobnd.enums;

public enum RetrospectiveStatus {
    NOT_STARTED,
    STARTED,
    FINISHED;

    public static final RetrospectiveStatus DEFAULT = NOT_STARTED;

}
