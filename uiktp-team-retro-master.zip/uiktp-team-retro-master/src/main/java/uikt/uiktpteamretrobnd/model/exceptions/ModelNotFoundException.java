package uikt.uiktpteamretrobnd.model.exceptions;

public class ModelNotFoundException extends RuntimeException{

}
