package uikt.uiktpteamretrobnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UiktpTeamRetroBndApplication {

    public static void main(String[] args) {
        SpringApplication.run(UiktpTeamRetroBndApplication.class, args);
    }

}
